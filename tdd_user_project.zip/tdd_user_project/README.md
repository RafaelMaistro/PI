# Projeto de TDD - Cadastro e Login de Usuário

## Sobre

Projeto exemplo utilizando TDD (Test Driven Development) com Python e PyTest. Implementa as funcionalidades de cadastro e login de usuários.

## Como executar

1. Clone o repositório:
```bash
git clone https://github.com/seuusuario/tdd_user_project.git
cd tdd_user_project
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Execute os testes:
```bash
pytest
```

## Funcionalidades

- Cadastro de usuário (com validação de e-mail duplicado e campos obrigatórios)
- Login com e-mail e senha

## Autor

Aluno de CIC – Projeto Integrador
